"""Core backend configuration modules."""
