import runpy
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'backend'))
runpy.run_path(str(root / 'backend/scripts/evaluate_rag.py'), run_name='__main__')
